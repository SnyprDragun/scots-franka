/*375:*/
#line 9 "./timing.w"

#ifndef VTIMING_H
#define VTIMING_H
double getTime();
double getTotalTime(double start_time,double end_time);
#endif

/*:375*/
