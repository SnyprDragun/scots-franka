var searchData=
[
  ['abs_5fptr_5ftype',['abs_ptr_type',['../namespacescots.html#a6c69a3c0145cbbe922de93a46e3bcf70',1,'scots']]],
  ['abs_5ftype',['abs_type',['../namespacescots.html#ada6a0cbabc01e198ebc8e503689de43a',1,'scots']]]
];
