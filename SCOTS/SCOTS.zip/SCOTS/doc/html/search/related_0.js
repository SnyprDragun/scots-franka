var searchData=
[
  ['write_5fto_5ffile',['write_to_file',['../classscots_1_1_static_controller.html#a9d3caf1f3e8b0a9fdf80922b7c578df3',1,'scots::StaticController::write_to_file()'],['../classscots_1_1_winning_domain.html#a9b95d93785f941950f6ffc6c33a7acd9',1,'scots::WinningDomain::write_to_file()']]]
];
