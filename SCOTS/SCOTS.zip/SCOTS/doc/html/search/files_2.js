var searchData=
[
  ['gamesolver_2ehh',['GameSolver.hh',['../_game_solver_8hh.html',1,'']]]
];
