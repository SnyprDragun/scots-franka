var searchData=
[
  ['abstraction',['Abstraction',['../classscots_1_1_abstraction.html',1,'scots']]]
];
