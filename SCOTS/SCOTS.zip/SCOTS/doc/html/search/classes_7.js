var searchData=
[
  ['winningdomain',['WinningDomain',['../classscots_1_1_winning_domain.html',1,'scots']]]
];
