var searchData=
[
  ['xtoi',['XtoI',['../classscots_1_1_uniform_grid.html#a5ac8614a863fca132e07f99da2c538bb',1,'scots::UniformGrid::XtoI(std::vector&lt; grid_point_t &gt; &amp;Xvector) const '],['../classscots_1_1_uniform_grid.html#afc7bace3d47c1407b3b539d211554195',1,'scots::UniformGrid::xtoi(const grid_point_t &amp;x) const ']]]
];
