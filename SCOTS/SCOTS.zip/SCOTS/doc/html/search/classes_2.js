var searchData=
[
  ['integerinterval',['IntegerInterval',['../classscots_1_1_integer_interval.html',1,'scots']]]
];
