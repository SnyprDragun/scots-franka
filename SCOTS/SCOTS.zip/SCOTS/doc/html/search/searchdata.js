var indexSectionsWithContent =
{
  0: "abcegimoprstuvwx",
  1: "aeistuw",
  2: "s",
  3: "aegirstuw",
  4: "abcegioprstuvwx",
  5: "m",
  6: "a",
  7: "w"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Friends"
};

